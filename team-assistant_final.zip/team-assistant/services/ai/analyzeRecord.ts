import { ApiError, GoogleGenAI } from "@google/genai";
import { AppError, Errors } from "@/lib/errors";
import { SYSTEM_PROMPT } from "./systemPrompt";
import { AI_JSON_SCHEMA } from "./schema";
import type { AIContext } from "./buildContext";
import { db } from "@/lib/db/client";
import { aiInteractions } from "@/lib/db/schema";

let client: GoogleGenAI | null = null;

export interface AnalyzeMeta {
  projectId: string;
  recordId: string;
}

function getClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw Errors.aiUnavailable();
  }
  if (!client) {
    client = new GoogleGenAI({ apiKey });
  }
  return client;
}

/**
 * Calls the LLM (Google Gemini) with the current project state + new
 * messages and returns the raw parsed JSON. Callers must run the result
 * through services/ai/validate.ts (validateAIResult) before touching the
 * database - this function only guarantees "valid JSON was returned", not
 * that its contents are safe/sane.
 *
 * Every call (success or failure) is persisted to the ai_interactions table
 * with the exact request payload and raw response/error, independent of
 * whatever validateAIResult() later decides is safe to apply. This is the
 * audit trail the hackathon rules require for any service that calls an
 * LLM: what was sent, what came back, when.
 */
export async function analyzeWithAI(
  context: AIContext,
  meta: AnalyzeMeta
): Promise<unknown> {
  const ai = getClient();
  const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
  const requestPayload = JSON.stringify(context);
  const startedAt = Date.now();

  const logInteraction = (fields: {
    status: "SUCCESS" | "ERROR";
    responseRaw?: string | null;
    errorMessage?: string | null;
  }) => {
    try {
      db.insert(aiInteractions)
        .values({
          projectId: meta.projectId,
          recordId: meta.recordId,
          provider: "gemini",
          model,
          requestPayload,
          status: fields.status,
          responseRaw: fields.responseRaw ?? null,
          errorMessage: fields.errorMessage ?? null,
          latencyMs: Date.now() - startedAt,
        })
        .run();
    } catch (logErr) {
      // Logging must never take down the actual analysis flow.
      console.error("Failed to persist ai_interactions row:", logErr);
    }
  };

  let text: string | undefined;
  try {
    const response = await ai.models.generateContent({
      model,
      contents: [
        {
          role: "user",
          parts: [
            {
              text:
                "다음은 현재 프로젝트 상태와 새로 입력된 기록이다. 이 JSON을 분석하여 지정된 스키마에 맞는 결과를 반환하라.\n\n" +
                JSON.stringify(context, null, 2),
            },
          ],
        },
      ],
      config: {
        systemInstruction: SYSTEM_PROMPT,
        temperature: 0.2,
        responseMimeType: "application/json",
        // Gemini accepts a standard JSON Schema via responseJsonSchema
        // (as opposed to its own restricted OpenAPI-subset `responseSchema`
        // type), so we can reuse a single shared schema definition instead
        // of maintaining a separate OpenAPI-subset schema dialect.
        responseJsonSchema: AI_JSON_SCHEMA.schema,
      },
    });
    text = response.text;
  } catch (err) {
    console.error("Gemini API call failed:", err);
    // Surface the specific failure mode instead of a generic "can't
    // connect" message - a stale/retired model name (404) is a very
    // different fix than a bad API key (401/403) or hitting a rate limit.
    let mapped: AppError;
    if (err instanceof ApiError) {
      if (err.status === 404) mapped = Errors.aiModelNotFound(model);
      else if (err.status === 401 || err.status === 403) mapped = Errors.aiAuthFailed();
      else if (err.status === 429) mapped = Errors.aiRateLimited();
      else mapped = Errors.aiUnavailable();
    } else {
      mapped = Errors.aiUnavailable();
    }
    logInteraction({ status: "ERROR", errorMessage: mapped.message });
    throw mapped;
  }

  if (!text) {
    logInteraction({ status: "ERROR", errorMessage: "empty response from model" });
    throw Errors.aiParsingFailed();
  }

  try {
    const parsed = JSON.parse(text);
    logInteraction({ status: "SUCCESS", responseRaw: text });
    return parsed;
  } catch (err) {
    console.error("Failed to parse AI JSON response:", err, text);
    logInteraction({ status: "ERROR", responseRaw: text, errorMessage: "invalid JSON in model response" });
    throw Errors.aiParsingFailed();
  }
}
