# DB Schema — Team Project Assistant

- 엔진: SQLite (파일 DB, `DATABASE_PATH` 환경변수, 기본 `./data/app.db`)
- ORM: Drizzle ORM (`lib/db/schema.ts`가 유일한 스키마 정의 소스), 마이그레이션은 `drizzle/*.sql` (drizzle-kit generate/migrate)
- PK: 전 테이블 `TEXT` UUID (`crypto.randomUUID()`)
- FK: 아래 표기된 관계는 모두 실제 SQLite `FOREIGN KEY` 제약으로 강제됨 (`PRAGMA foreign_keys = ON`, `lib/db/client.ts`)

## 엔티티-테이블 매핑 및 관계

| 엔티티 | 테이블 | 관계 |
|---|---|---|
| Project | `projects` | 1 |
| Member | `members` | Project 1—N Member |
| Record | `records` | Project 1—N Record |
| Task | `tasks` | Project 1—N Task, Member 1—N Task (담당, nullable) |
| Evidence | `evidence` | Task 1—N Evidence, Record 1—N Evidence |
| AiInteraction | `ai_interactions` | Project 1—N AiInteraction, Record 1—N AiInteraction |
| ContributionSnapshot | `contribution_snapshots` | Project 1—N ContributionSnapshot, Record 1—N ContributionSnapshot (nullable) |
| RecordChange | `record_changes` | Project 1—N RecordChange, Record 1—N RecordChange |

M:N 관계는 없음 (Task→Member는 "현재 담당자 1명" 모델이라 N:1). 모든 관계가 1:N이며, 하위 엔티티는 상위 엔티티 삭제 시 `ON DELETE CASCADE`로 함께 삭제됩니다(단, Task.assigneeId는 Member 삭제 시 `ON DELETE SET NULL` — Task 자체는 남고 담당자만 해제).

## ER 다이어그램 (텍스트)

```
projects (1) ──< members (N)
projects (1) ──< records (N)
projects (1) ──< tasks (N)
projects (1) ──< ai_interactions (N)
projects (1) ──< contribution_snapshots (N)
projects (1) ──< record_changes (N)

members (1) ──< tasks (N)              [tasks.assignee_id, ON DELETE SET NULL]

records (1) ──< evidence (N)           [evidence.record_id, ON DELETE CASCADE]
records (1) ──< ai_interactions (N)    [ai_interactions.record_id, ON DELETE CASCADE]
records (1) ──< contribution_snapshots [contribution_snapshots.record_id, ON DELETE SET NULL]
records (1) ──< record_changes (N)     [record_changes.record_id, ON DELETE CASCADE]

tasks (1) ──< evidence (N)             [evidence.task_id, ON DELETE CASCADE]
```

## 테이블 상세

### `projects`
| column | type | 설명 |
|---|---|---|
| id | TEXT PK | UUID |
| name | TEXT NOT NULL | 프로젝트명 |
| created_at | INTEGER (ms epoch) | |
| updated_at | INTEGER (ms epoch) | |

### `members`
| column | type | 설명 |
|---|---|---|
| id | TEXT PK | UUID |
| project_id | TEXT NOT NULL, FK → projects.id (CASCADE) | |
| name | TEXT NOT NULL | 팀원 이름 (프로젝트 내 유니크, 애플리케이션 레벨 검증) |
| created_at | INTEGER (ms epoch) | |

### `records`
카카오톡 대화 또는 수동 입력 회의 기록 원본 1건.

| column | type | 설명 |
|---|---|---|
| id | TEXT PK | UUID |
| project_id | TEXT NOT NULL, FK → projects.id (CASCADE) | |
| type | TEXT NOT NULL | `KAKAO_TEXT` \| `MANUAL_TEXT` |
| raw_content | TEXT NOT NULL | 사용자가 붙여넣은 원문 |
| analysis_status | TEXT NOT NULL, default `PENDING` | `PENDING` \| `ANALYZING` \| `COMPLETED` \| `FAILED` |
| analysis_error | TEXT nullable | 실패 시 사용자향 에러 메시지 |
| analyzed_at | INTEGER (ms epoch) nullable | 분석 완료 시각 |
| created_at | INTEGER (ms epoch) | |

### `tasks`
| column | type | 설명 |
|---|---|---|
| id | TEXT PK | UUID |
| project_id | TEXT NOT NULL, FK → projects.id (CASCADE) | |
| title | TEXT NOT NULL | |
| assignee_id | TEXT nullable, FK → members.id (SET NULL) | 현재 담당자 (1명, 공동작업 미지원) |
| status | TEXT NOT NULL, default `TODO` | `TODO` \| `IN_PROGRESS` \| `DONE` |
| importance / difficulty / workload | INTEGER NOT NULL, default 3 | 1–5 척도, AI 평가 결과 (기여도 계산의 입력값) |
| last_reason | TEXT nullable | 최근 변경에 대한 AI의 자연어 근거 |
| is_deleted | INTEGER(bool) NOT NULL, default false | 소프트 삭제 플래그 |
| created_at / updated_at | INTEGER (ms epoch) | |

### `evidence`
Task 하나의 주장을 뒷받침하는 원문 발화 조각. AI는 이 근거 없이는 Task를 생성/변경하지 않음(hallucination 방지 규칙).

| column | type | 설명 |
|---|---|---|
| id | TEXT PK | UUID |
| task_id | TEXT NOT NULL, FK → tasks.id (CASCADE) | |
| record_id | TEXT NOT NULL, FK → records.id (CASCADE) | 이 근거가 나온 원본 기록 |
| speaker | TEXT NOT NULL | 발화자 |
| text | TEXT NOT NULL | 발화 원문 |
| timestamp | TEXT nullable | 파싱된 카카오톡 타임스탬프(있는 경우) |
| created_at | INTEGER (ms epoch) | |

### `ai_interactions` *(신규 — LLM 요청/응답 감사 로그)*
분석 호출마다 성공/실패와 무관하게 정확히 1행이 남습니다. `services/ai/analyzeRecord.ts`가 직접 기록하며, 이후 `validateAIResult()`가 결과를 어떻게 해석했는지와 무관한 "실제로 모델에 보낸 요청 / 모델이 반환한 응답 원문"의 원본 기록입니다.

| column | type | 설명 |
|---|---|---|
| id | TEXT PK | UUID |
| project_id | TEXT NOT NULL, FK → projects.id (CASCADE) | |
| record_id | TEXT NOT NULL, FK → records.id (CASCADE) | |
| provider | TEXT NOT NULL, default `gemini` | LLM 제공자 |
| model | TEXT NOT NULL | 실제 호출된 모델명 (예: `gemini-2.5-flash`) |
| request_payload | TEXT NOT NULL | `buildAIContext()`가 만든 컨텍스트 JSON 전체 (stringified) |
| status | TEXT NOT NULL, default `PENDING` | `SUCCESS` \| `ERROR` |
| response_raw | TEXT nullable | 모델이 반환한 원문 텍스트/JSON (성공 시) |
| error_message | TEXT nullable | 실패 사유 (모델 미존재/인증 실패/rate limit/파싱 실패 등) |
| latency_ms | INTEGER nullable | 요청~응답 소요 시간 |
| created_at | INTEGER (ms epoch) | |

용도: (1) 심사 기준의 "LLM 요청/응답 이력을 DB에 저장" 요건 충족, (2) 장애 디버깅 시 실제로 무엇을 보내고 받았는지 재현, (3) 추후 동일 요청 재호출 방지(캐싱)에 활용 가능한 기반 데이터.

### `contribution_snapshots`
분석 1회가 끝날 때마다 그 시점의 팀원별 기여도를 스냅샷으로 저장 (증감(`deltaPercentage`) 계산의 기준점).

| column | type | 설명 |
|---|---|---|
| id | TEXT PK | UUID |
| project_id | TEXT NOT NULL, FK → projects.id (CASCADE) | |
| record_id | TEXT nullable, FK → records.id (SET NULL) | |
| scores | TEXT NOT NULL | JSON: `{ memberId, name, rawScore, percentage }[]` |
| created_at | INTEGER (ms epoch) | |

### `record_changes`
분석 1회가 만든 변경 사항의 사람이 읽을 수 있는 로그 (대시보드 "최근 변경사항" 표시용).

| column | type | 설명 |
|---|---|---|
| id | TEXT PK | UUID |
| project_id | TEXT NOT NULL, FK → projects.id (CASCADE) | |
| record_id | TEXT NOT NULL, FK → records.id (CASCADE) | |
| task_id | TEXT nullable | (FK 제약 없음 — Task가 이후 소프트 삭제되어도 로그는 보존) |
| task_title | TEXT NOT NULL | |
| change_type | TEXT NOT NULL | `TASK_CREATE` \| `TASK_STATUS_CHANGE` \| `TASK_ASSIGNEE_CHANGE` \| `TASK_UPDATE` \| `EVIDENCE_ADD` |
| summary | TEXT NOT NULL | 예: `"할 일 → 진행 중"` |
| reason | TEXT nullable | AI 근거 |
| confidence | REAL nullable | AI 확신도 (0–1) |
| created_at | INTEGER (ms epoch) | |

## 설계 절차 요약

1. 요구사항의 명사(프로젝트/팀원/기록/Task/근거/기여도/변경이력)를 엔티티로 추출.
2. 각 엔티티의 소유 관계(프로젝트 하위 리소스인가, 다른 엔티티에 종속적인가)를 기준으로 1:N FK 방향을 결정 — 이 도메인에는 M:N이 필요한 관계가 없음(담당자는 항상 0/1명).
3. "AI가 실제로 무엇을 근거로 판단했는지"를 감사 가능하게 만들기 위해 `evidence`(검증된 근거)와 `ai_interactions`(검증 이전의 원본 요청/응답)를 별도 테이블로 분리 — 하나로 합치면 "AI가 뭘 받았고 뭘 반환했는가"와 "그중 무엇을 실제로 반영했는가"가 뒤섞임.
4. 소프트 삭제(`tasks.is_deleted`)를 선택한 이유: Task가 삭제되어도 `evidence`/`record_changes` 이력이 참조 무결성을 유지한 채 보존되어야 하기 때문 (물리 삭제 시 CASCADE로 근거까지 사라짐).
