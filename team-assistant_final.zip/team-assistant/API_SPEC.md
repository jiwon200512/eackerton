# API Specification — Team Project Assistant

모든 엔드포인트는 Next.js Route Handler(`app/api/**/route.ts`)로 구현되어 있으며, 서버에서만 실행됩니다. `GEMINI_API_KEY`는 서버 프로세스 환경변수로만 존재하고 클라이언트로 전달되지 않습니다(클라이언트는 `lib/apiClient.ts`를 통해 아래 REST 엔드포인트만 호출합니다).

- Base URL: `http://localhost:3000` (로컬 개발 기준)
- 데이터 포맷: 모든 요청/응답 body는 `application/json`
- 인증: 없음 (단일 사용자/해커톤 데모 범위, `알려진 제한사항` 참고)
- 공통 에러 응답 포맷:

```json
{ "error": "사람이 읽을 수 있는 한국어 메시지", "code": "MACHINE_READABLE_CODE" }
```

에러 코드와 HTTP status 매핑은 `lib/errors.ts`의 `Errors` 팩토리에 정의되어 있으며, 아래 표는 각 엔드포인트에서 실제로 발생할 수 있는 코드만 나열합니다.

| status | code | 의미 |
|---|---|---|
| 400 | `EMPTY_INPUT` / `INVALID_NAME` / `INVALID_TYPE` / `INVALID_TITLE` / `INVALID_STATUS` / `INVALID_ASSIGNEE` | 잘못된 요청 body |
| 400 | `NO_MEMBERS` | 팀원이 없는 프로젝트에서 분석 시도 |
| 404 | `NOT_FOUND` | 프로젝트/팀원/기록/Task 없음 |
| 409 | `DUPLICATE_MEMBER` | 같은 이름의 팀원 중복 등록 |
| 409 | `ALREADY_ANALYZED` / `ALREADY_ANALYZING` | 이미 분석 완료/진행 중인 기록 재분석 시도 (force 없이) |
| 500 | `DB_ERROR` / `UNKNOWN` | 서버 내부 오류 |
| 502 | `AI_UNAVAILABLE` / `AI_MODEL_NOT_FOUND` / `AI_AUTH_FAILED` / `AI_RATE_LIMITED` / `AI_PARSING_FAILED` | LLM 호출 실패 (사유별 세분화) |

---

## Projects

### `GET /api/projects`
프로젝트 목록 조회 (최신순).

- Response `200`: `{ "projects": Project[] }`
  - `Project`: `{ id: string; name: string; createdAt: string; updatedAt: string }` (timestamp는 ISO 문자열로 직렬화됨)

### `POST /api/projects`
프로젝트 생성.

- Request body: `{ "name": string }`
- Response `201`: `{ "project": Project }`
- Errors: `400 INVALID_NAME` (name 비어있음)

### `GET /api/projects/:projectId`
프로젝트 상세 + 팀원 목록.

- Response `200`: `{ "project": Project, "members": Member[] }`
  - `Member`: `{ id: string; projectId: string; name: string; createdAt: string }`
- Errors: `404 NOT_FOUND`

---

## Members

### `GET /api/projects/:projectId/members`
팀원 목록 조회.

- Response `200`: `{ "members": Member[] }`

### `POST /api/projects/:projectId/members`
팀원 등록.

- Request body: `{ "name": string }`
- Response `201`: `{ "member": Member }`
- Errors: `404 NOT_FOUND`(프로젝트 없음), `400 INVALID_NAME`, `409 DUPLICATE_MEMBER`

### `DELETE /api/projects/:projectId/members/:memberId`
팀원 삭제. 해당 팀원이 담당 중이던 Task는 `assigneeId`가 `NULL`로 자동 변경됩니다(DB `ON DELETE SET NULL`).

- Response `200`: `{ "ok": true }`
- Errors: `404 NOT_FOUND`

---

## Records (카카오톡/회의 기록)

### `GET /api/projects/:projectId/records`
기록 목록 조회 (최신순).

- Response `200`: `{ "records": Record[] }`
  - `Record`: `{ id, projectId, type: "KAKAO_TEXT"|"MANUAL_TEXT", rawContent: string, analysisStatus: "PENDING"|"ANALYZING"|"COMPLETED"|"FAILED", analysisError: string|null, analyzedAt: string|null, createdAt: string }`

### `POST /api/projects/:projectId/records`
새 기록 생성 (아직 분석 전, `analysisStatus: "PENDING"`).

- Request body: `{ "type": "KAKAO_TEXT" | "MANUAL_TEXT", "rawContent": string }`
- Response `201`: `{ "record": Record }`
- Errors: `404 NOT_FOUND`, `400 INVALID_TYPE`, `400 EMPTY_INPUT`

### `POST /api/projects/:projectId/records/:recordId/analyze`
핵심 파이프라인 엔드포인트. 기록을 파싱 → AI 분석(Gemini) → 검증 → Task/Evidence/기여도 갱신까지 한 번에 수행합니다.

- Request body (optional): `{ "force"?: boolean }` — 이미 `COMPLETED` 상태인 기록을 재분석하려면 `true` 필요.
- Response `200`:
  ```json
  {
    "changes": [
      { "taskId": "string", "taskTitle": "string", "changeType": "TASK_CREATE|TASK_STATUS_CHANGE|TASK_ASSIGNEE_CHANGE|TASK_UPDATE|EVIDENCE_ADD", "summary": "string", "reason": "string|null", "confidence": "number|null" }
    ],
    "contribution": [
      { "memberId": "string", "name": "string", "rawScore": "number", "percentage": "number" }
    ],
    "usedFallback": "boolean",
    "eventCount": "number"
  }
  ```
- Errors: `404 NOT_FOUND`, `409 ALREADY_ANALYZED`, `409 ALREADY_ANALYZING`, `400 NO_MEMBERS`, `400 EMPTY_INPUT`, `502 AI_UNAVAILABLE`/`AI_MODEL_NOT_FOUND`/`AI_AUTH_FAILED`/`AI_RATE_LIMITED`/`AI_PARSING_FAILED`
- 부작용: 성공/실패 여부와 관계없이 `ai_interactions` 테이블에 실제 LLM 요청/응답(or 에러) 1행이 기록됩니다 (`DB_SCHEMA.md` 참고).

---

## Tasks

### `GET /api/projects/:projectId/tasks`
활성 Task 목록 (삭제되지 않은 것만), 진행중 → 할일 → 완료 순, 그룹 내 최신 수정순 정렬.

- Response `200`: `{ "tasks": TaskDTO[] }`
  - `TaskDTO`: `{ id, projectId, title, assigneeId: string|null, assigneeName: string|null, status: "TODO"|"IN_PROGRESS"|"DONE", importance: 1-5, difficulty: 1-5, workload: 1-5, taskScore: number, currentScore: number, lastReason: string|null, createdAt: number, updatedAt: number }`
  - `taskScore`: importance × difficulty × workload 기반 최종 기여도 반영 점수(완료 시), `currentScore`: 현재 상태 기준 진행 중 점수. 계산 로직은 `services/contribution/calculate.ts` (LLM 미개입, 결정론적 계산).

### `GET /api/projects/:projectId/tasks/:taskId`
Task 상세 + Evidence 목록 + 프로젝트 팀원 목록(담당자 변경 UI용).

- Response `200`: `{ "task": TaskDTO, "evidence": Evidence[], "members": Member[] }`
  - `Evidence`: `{ id, taskId, recordId, speaker, text, timestamp: string|null, createdAt: string }`
- Errors: `404 NOT_FOUND`

### `PATCH /api/projects/:projectId/tasks/:taskId`
사람이 직접 Task를 수정 (제목/상태/담당자). **이 엔드포인트로 수정된 값은 이후 AI 재분석에서도 그대로 유지되는 authoritative 값으로 취급됩니다** (`services/tasks/applyEvents.ts` + AI 시스템 프롬프트의 "manual edit is authoritative" 규칙).

- Request body (모두 optional, 보낸 필드만 갱신): `{ "title"?: string, "status"?: "TODO"|"IN_PROGRESS"|"DONE", "assigneeId"?: string|null }`
- Response `200`: `{ "task": TaskDTO }`
- Errors: `404 NOT_FOUND`, `400 INVALID_TITLE`/`INVALID_STATUS`/`INVALID_ASSIGNEE`

### `DELETE /api/projects/:projectId/tasks/:taskId`
Task 소프트 삭제 (`isDeleted = true`). 물리 삭제하지 않아 관련 Evidence/변경 이력은 보존됩니다.

- Response `200`: `{ "ok": true }`
- Errors: `404 NOT_FOUND`

> 참고: Task를 수동으로 "생성"하는 엔드포인트는 의도적으로 제공하지 않습니다. Task는 반드시 AI 분석(`POST .../analyze`)을 통해서만 생성되므로, "AI 기능을 제거하면 핵심 서비스가 동작하지 않는다"는 주제 적합성 조건을 코드 구조로 보장합니다.

---

## Contribution (기여도)

### `GET /api/projects/:projectId/contribution`
현재 기여도(실시간 재계산) + 직전 스냅샷 대비 변화량.

- Response `200`:
  ```json
  {
    "contribution": [
      { "memberId": "string", "name": "string", "rawScore": "number", "percentage": "number", "deltaPercentage": "number|null" }
    ],
    "lastSnapshotAt": "number|null"
  }
  ```
  - `percentage`의 합은 항상 정확히 100.0 (largest-remainder 반올림, `services/contribution/calculate.ts`).
  - `deltaPercentage`: 직전 분석 스냅샷 대비 증감(%p), 스냅샷이 없으면 `null`.

---

## Recent Changes (최근 변경사항)

### `GET /api/projects/:projectId/recent-changes`
가장 최근에 완료된 분석 1건이 만든 변경 목록 (대시보드 "최근 변경사항" 패널용).

- Response `200`: `{ "recordId": "string|null", "analyzedAt": "number|null", "changes": RecentChangeDTO[] }`
  - `RecentChangeDTO`: `{ id, taskId: string|null, taskTitle, changeType, summary, reason: string|null, confidence: number|null, createdAt: number }`
