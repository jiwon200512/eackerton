CREATE TABLE `ai_interactions` (
	`id` text PRIMARY KEY NOT NULL,
	`project_id` text NOT NULL,
	`record_id` text NOT NULL,
	`provider` text DEFAULT 'gemini' NOT NULL,
	`model` text NOT NULL,
	`request_payload` text NOT NULL,
	`status` text DEFAULT 'PENDING' NOT NULL,
	`response_raw` text,
	`error_message` text,
	`latency_ms` integer,
	`created_at` integer DEFAULT (strftime('%s','now') * 1000) NOT NULL,
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`record_id`) REFERENCES `records`(`id`) ON UPDATE no action ON DELETE cascade
);
